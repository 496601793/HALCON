// halcontestDlg.h : ͷ�ļ�

#pragma once
#include "HalconCpp.h"
#include "HObject.h"
using namespace HalconCpp;

// ChalcontestDlg �Ի���
DWORD WINAPI ThreadB1( LPVOID lpParam );
class ChalcontestDlg : public CDialog
{
// ����
public:
	ChalcontestDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_HALCONTEST_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��



// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnBnClickedButton1();
	//HObject  m_LiveImage;
	HObject m_LiveImage;

	HTuple m_HWindowID;
	HTuple  AcqHandle;
	void InitHalconWindow();
	HANDLE  m_hThreadcamera1;
	HTuple HWindowRow,HWindowColumn,HWindowWidth,HWindowHeight;
	HTuple m_FGHandle,m_ImageWidth, m_ImageHeight;
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	void  Grab();
	bool m_stop;
public:
	afx_msg void OnBnClickedButton4();
public:
	afx_msg void OnBnClickedButton5();
public:
	CString pathname;
public:
	const HTuple Filename;
	HObject  ho_Images;
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
public:
	afx_msg void OnBnClickedButton6();
};
